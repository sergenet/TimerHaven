# convert-and-zip.ps1
# Place in your site folder (C:\TimerHavenWebsite) and run:
#   powershell -ExecutionPolicy Bypass -File .\convert-and-zip.ps1
# What it does:
# 1) Full mirror backup to C:\TimerHavenWebsite_full_backup
# 2) For each .html:
#    - If file is valid UTF-8: optionally remove BOM
#    - Else: assume Windows-1252 and convert to UTF-8 (no BOM)
#    - Save original as .enc.bak beside file when conversion happens or when BOM removed
# 3) Copy everything (excluding node_modules and backup files) to a temp folder
#    and create timerhaven_upload.zip in the site root.
# 4) Leaves .enc.bak files and shows a summary.

$SiteRoot = (Get-Location).Path
$FullBackup = Join-Path -Path $SiteRoot -ChildPath '..\TimerHavenWebsite_full_backup'
$TempCopy = Join-Path -Path $env:TEMP -ChildPath "timerhaven_upload_tmp"
$ZipPath = Join-Path -Path $SiteRoot -ChildPath 'timerhaven_upload.zip'

Write-Output "Site root: $SiteRoot"
Write-Output "Full backup location: $FullBackup"
Write-Output "Temp copy location: $TempCopy"
Write-Output "Zip output: $ZipPath"
Write-Output ""

# 1) Full backup (robocopy mirror)
if (-not (Test-Path $FullBackup)) { New-Item -ItemType Directory -Path $FullBackup | Out-Null }
Write-Output "Creating full mirror backup (this may take a while)..."
robocopy $SiteRoot $FullBackup /MIR /NFL /NDL /NJH /NJS /NP | Out-Null
Write-Output "Full backup done."

# Helper encodings
$encUtf8 = [System.Text.Encoding]::UTF8
$enc1252 = [System.Text.Encoding]::GetEncoding(1252)

$changed = @()
$skipped = @()
$errors = @()

# 2) Convert HTML files
Write-Output "Scanning and converting .html files to UTF-8 (no BOM) if needed..."
Get-ChildItem -Path $SiteRoot -Filter *.html -Recurse -File | ForEach-Object {
  $path = $_.FullName
  try {
    $bytes = [System.IO.File]::ReadAllBytes($path)

    # Detect BOM
    $hasBom = ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF)

    # Try to decode as UTF8 and re-encode to compare bytes
    $utf8String = $encUtf8.GetString($bytes)
    $reencoded = $encUtf8.GetBytes($utf8String)

    $isValidUtf8 = $false
    if ($reencoded.Length -eq $bytes.Length) {
      $isValidUtf8 = $true
      for ($i=0; $i -lt $bytes.Length; $i++) {
        if ($bytes[$i] -ne $reencoded[$i]) { $isValidUtf8 = $false; break }
      }
    }

    if ($isValidUtf8) {
      # It's valid UTF-8. If it has BOM, remove BOM (write utf8 without BOM).
      if ($hasBom) {
        $bak = $path + '.enc.bak'
        Copy-Item -LiteralPath $path -Destination $bak -Force
        # remove BOM from bytes
        $newBytes = $bytes[3..($bytes.Length - 1)]
        [System.IO.File]::WriteAllBytes($path, $newBytes)
        $changed += $path
        Write-Output "Removed BOM: $path (backup: $bak)"
      } else {
        $skipped += $path
      }
    } else {
      # Not valid UTF-8 -> assume Windows-1252, convert to UTF-8 (no BOM)
      $bak = $path + '.enc.bak'
      Copy-Item -LiteralPath $path -Destination $bak -Force
      $text = $enc1252.GetString($bytes)
      [System.IO.File]::WriteAllText($path, $text, $encUtf8)
      $changed += $path
      Write-Output "Converted (1252 -> UTF-8): $path (backup: $bak)"
    }
  } catch {
    $errors += "ERROR processing $path : $($_.Exception.Message)"
    Write-Warning ("ERROR processing " + $path + " : " + $_.Exception.Message)
  }
}

Write-Output ""
Write-Output ("Conversion complete. Files changed: " + $changed.Count + ", skipped (already UTF8): " + $skipped.Count)
if ($errors.Count -gt 0) { Write-Output ("Errors: " + $errors.Count); $errors | ForEach-Object { Write-Output $_ } }

# 3) Prepare temp copy excluding node_modules and backup/support files
Write-Output "Preparing temporary copy (excluding node_modules and *.bak / *.ps1 / *.enc.bak)..."
if (Test-Path $TempCopy) { Remove-Item -Recurse -Force $TempCopy -ErrorAction SilentlyContinue }
New-Item -ItemType Directory -Path $TempCopy | Out-Null

# Use robocopy to mirror while excluding folders/files
$excludeDirs = @("node_modules")
$excludeFiles = @("*.bak","*.ps1","*.enc.bak","timerhaven_upload.zip","patch-log.txt","patch-scan.txt")

# Build robocopy arguments
$xdArgs = $excludeDirs | ForEach-Object { "/XD `"$SiteRoot\$_`"" } | Out-String
$xfArgs = $excludeFiles | ForEach-Object { "/XF `"$SiteRoot\$_`"" } | Out-String

# Simpler call: use robocopy with /XD and /XF supplying the names (robocopy accepts relative names)
robocopy $SiteRoot $TempCopy /MIR /XD "node_modules" /XF "*.bak" "*.ps1" "*.enc.bak" "timerhaven_upload.zip" "patch-log.txt" "patch-scan.txt" /NFL /NDL /NP | Out-Null
Write-Output "Temporary copy created."

# 4) Create ZIP
if (Test-Path $ZipPath) { Remove-Item -Force $ZipPath }
Write-Output "Creating ZIP $ZipPath ..."
Compress-Archive -Path (Join-Path $TempCopy '*') -DestinationPath $ZipPath -Force
Write-Output "ZIP created: $ZipPath"

# Cleanup temp copy
Remove-Item -Recurse -Force $TempCopy -ErrorAction SilentlyContinue
Write-Output "Temporary files cleaned."

Write-Output ""
Write-Output "Summary:"
Write-Output ("  Full backup (mirror): " + $FullBackup)
Write-Output ("  Files converted/modified (enc.bak created): " + $changed.Count)
if ($changed.Count -gt 0) { $changed | ForEach-Object { Write-Output ("    " + $_) } }
Write-Output ("  ZIP ready for upload: " + $ZipPath)
Write-Output ""
Write-Output "If anything looks wrong, you can restore individual files from *.enc.bak backups or restore the full mirror at:"
Write-Output ("  robocopy " + $FullBackup + " " + $SiteRoot + " /MIR")